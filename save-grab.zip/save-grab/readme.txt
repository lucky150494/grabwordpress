=== Plugin Name ===
Contributors: neobie
Donate link: http://digitalmemo.neobie.net/grab-save
Tags: download, grab, image, picture, remote, save, upload
Requires at least: 2.8
Tested up to: 3.5
Stable tag: trunk

This plugin allow you to grab and save the image from remote url into your own wordpress media library.

== Description ==

This plugin allow you to grab image from remote url and save into your own wordpress media library. By doing so, you never worried if the remote image was removed by its owner. This also save you steps to download the image to local computer and upload again to your own wordpress.

After grabbing the image, wordpress will prompt you either to "insert into post" or "change attributes" just like after you upload an image. Renaming is available.

== Installation ==

Simpy install from your wordpress plugin page and activate it. Usage: the Grab & Save tab is located at the "Add an image"

== Changelog ==

= 1.0.4 =
 * Rename the file before grab & saving

= 1.0.3 =
 * Compatible up to Wordpress 3.5

= 1.0.2 =
 * Compatible up to Wordpress 3.3

= 1.0.1 =
 * Fix empty image being saved problem due to apostrophe in URL. Credited to marikamitsos.

= 1.0.0 =
 * Initial release.

== Screenshots ==

1. Just put in the URL and click "grab".
2. The image is "grabbed & saved" to your media library. You may customize the image and insert to your post.